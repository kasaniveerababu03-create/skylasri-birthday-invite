SKYLASRI SMRITHI — FREE BIRTHDAY INVITATION WEBSITE

1. Add your daughter's chosen photo to this folder and name it exactly:
   baby-photo.jpg
2. Open https://github.com/ and create a free account (if needed).
3. Create a new PUBLIC repository, for example: skylasri-birthday-invite
4. Upload index.html and baby-photo.jpg to the repository root.
5. Open repository Settings → Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select branch 'main' and folder '/ (root)', then Save.
8. Wait a minute or two. GitHub will show your free website link under Pages.

The page uses no paid domain or hosting. The WhatsApp RSVP button opens WhatsApp
with a pre-filled response; guests can choose a chat/contact. The map button
searches the venue name in Google Maps.
